# Woolhud
This is a recreation of the HUD woolen is seen using in his YouTube videos and in his Twitch streams if you're into watching those.

# Important Information
This HUD is for 16:9 resolution users so if you play with 4:3 IN GAME, nevermind that you have 16:9 monitor, you have to play IN GAME 16:9 
DO NOT remove any file from this hud exept readme or sound you can delete this
